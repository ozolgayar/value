import json, struct, math, io
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
ROOT=Path(__file__).parent; OUT=ROOT/'public'; OUT.mkdir(exist_ok=True)
sections=[
 {'id':'foundation','title':'Фундамент — ценности','items':['Страсть — Мы увлечены работой','Амбициозность — Мы устремлены в будущее','Ответственность — Мы отвечаем за результат']},
 {'id':'floor1','title':'1 этаж. Команда и лидерство','items':['Трансформация культуры','Лидерство и карьера','Эффективность и мотивация','Мышление долголетия','Сильный бренд работодателя','СИ: ГЕРОФАРМ — лучший работодатель фармацевтического рынка России']},
 {'id':'floor2','title':'2 этаж. Бизнес-процессы и производство','items':['СИ: Развитие биотехнологического производства для увеличения годовой мощности до 2000 кг в год','СИ: Модернизация производства продуктов экстрактов сухих для увеличения годовой мощности производства','СИ: Повышение мощности и эффективности производства ТЛФ до 1 миллиарда таблеток в год','Производственная площадка в Пушкине','Производственная площадка в Оболенске','СИ: Модернизация производства продуктов в шприц-ручках, флаконированных и картриджных форм','СИ: Модернизация производства биотехнологических субстанций','Цель производственных площадок: Обеспечить бездефектурное производство препаратов','СИ: Развитие интегрированного бизнес-планирования']},
 {'id':'floor3','title':'3 этаж. Портфель и рынки','items':['СИ: Инновации','СИ: Формирование портфеля продуктами с выручкой до 1 млрд*','СИ: Развитие функции обеспечения доступа на рынок','СИ: Наполнение портфеля биоаналогами, препаратами first-in-class, best-in-class через партнерство','СИ: Лидерство в сегменте метаболическое здоровье','СИ: Обеспечение эффективности продаж продуктов основного портфеля','СИ: Развитие экспорта']},
 {'id':'floor4','title':'4 этаж. Финансовые показатели','items':['EBITDA ≥ 35%','Рентабельность по валовой прибыли ≥ 55%','ROA** > 15% (эффективность активов)','ROE*** > 25% (отдача на капитал)']},
 {'id':'mission','title':'Миссия компании','items':['Создаем инновации для увеличения продолжительности жизни в России и мире']}
]
(OUT/'sections.json').write_text(json.dumps(sections,ensure_ascii=False,indent=2),encoding='utf-8')
g={'asset':{'version':'2.0','generator':'Geropharm procedural reconstruction v1'},'scene':0,'scenes':[{'nodes':[0]}],'nodes':[{'name':'House','children':[]}],'meshes':[],'materials':[],'accessors':[],'bufferViews':[],'images':[],'textures':[],'samplers':[{'magFilter':9729,'minFilter':9987,'wrapS':33071,'wrapT':33071}]}; binary=bytearray(); parents={}
for s in sections+[{'id':'environment'}]:
 parents[s['id']]=len(g['nodes']);g['nodes'][0]['children'].append(len(g['nodes']));g['nodes'].append({'name':s['id'],'extras':{'sectionId':s['id']},'children':[]})
def view(data,target=None):
 while len(binary)%4: binary.append(0)
 v={'buffer':0,'byteOffset':len(binary),'byteLength':len(data)}
 if target: v['target']=target
 binary.extend(data);g['bufferViews'].append(v);return len(g['bufferViews'])-1

def acc(values,typ):
 flat=[v for row in values for v in row]; a={'bufferView':view(struct.pack('<'+'f'*len(flat),*flat),34962),'componentType':5126,'count':len(values),'type':typ}
 if typ=='VEC3': a.update(min=[min(r[i] for r in values) for i in range(3)],max=[max(r[i] for r in values) for i in range(3)])
 g['accessors'].append(a);return len(g['accessors'])-1
palette={'cream':(.87,.8,.64),'peach':(1,.56,.33),'glass':(.12,.77,.65),'teal':(.025,.48,.4),'green':(.06,.35,.24),'metal':(.56,.64,.65),'base':(.68,.74,.77),'orange':(1,.4,.09)}
cache={}
def material(sec,kind):
 key=(sec,kind)
 if key in cache:return cache[key]
 c=palette[kind]; m={'name':sec+'_'+kind,'pbrMetallicRoughness':{'baseColorFactor':[*c,1],'metallicFactor':.12 if kind=='metal' else 0,'roughnessFactor':.32 if kind=='glass' else .8},'emissiveFactor':[.01,.045,.03] if kind=='glass' else [0,0,0],'extras':{'sectionId':sec,'role':kind}}
 g['materials'].append(m);cache[key]=len(g['materials'])-1;return cache[key]
def mesh(name,sec,p,n,uv,mat):
 prim={'attributes':{'POSITION':acc(p,'VEC3'),'NORMAL':acc(n,'VEC3')},'material':mat}
 if uv:prim['attributes']['TEXCOORD_0']=acc(uv,'VEC2')
 g['meshes'].append({'name':name,'primitives':[prim]}); node={'name':name,'mesh':len(g['meshes'])-1,'extras':{'sectionId':sec}}
 g['nodes'][parents[sec]]['children'].append(len(g['nodes']));g['nodes'].append(node)
def box(name,sec,x,y,z,w,h,d,kind='cream'):
 corners=[(x+a*w/2,y+b*h/2,z+c*d/2) for a,b,c in [(-1,-1,-1),(1,-1,-1),(1,1,-1),(-1,1,-1),(-1,-1,1),(1,-1,1),(1,1,1),(-1,1,1)]]
 faces=[((0,3,2,1),(0,0,-1)),((4,5,6,7),(0,0,1)),((0,4,7,3),(-1,0,0)),((1,2,6,5),(1,0,0)),((3,7,6,2),(0,1,0)),((0,1,5,4),(0,-1,0))];p=[];n=[]
 for f,norm in faces:
  for i in [0,1,2,0,2,3]:p.append(corners[f[i]]);n.append(norm)
 mesh(name,sec,p,n,None,material(sec,kind))
fontpath='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
def label(name,sec,text,x,y,z,w,h,bg='#d0e9df',fg='#173f39',side=False):
 W=min(2048,max(512,int(w*170)));H=max(128,int(W*h/w));im=Image.new('RGB',(W,H),bg);draw=ImageDraw.Draw(im);margin=max(12,int(W*.035))
 for size in range(min(100,H//2),7,-1):
  font=ImageFont.truetype(fontpath,size);lines=[]
  for para in text.split('\n'):
   row=''
   for word in para.split():
    test=(row+' '+word).strip()
    if draw.textlength(test,font=font)>W-2*margin and row:lines.append(row);row=word
    else:row=test
   lines.append(row)
  lineh=int(size*1.3)
  if len(lines)*lineh<=H-2*margin:break
 yy=(H-len(lines)*lineh)/2
 for line in lines:
  draw.text((margin,yy),line,font=font,fill=fg);yy+=lineh
 buf=io.BytesIO();im.save(buf,format='PNG'); g['images'].append({'bufferView':view(buf.getvalue()),'mimeType':'image/png','name':name});g['textures'].append({'source':len(g['images'])-1,'sampler':0})
 g['materials'].append({'name':sec+'_text_'+name,'pbrMetallicRoughness':{'baseColorFactor':[1,1,1,1],'baseColorTexture':{'index':len(g['textures'])-1},'metallicFactor':0,'roughnessFactor':1},'doubleSided':True,'extras':{'sectionId':sec,'role':'text'}})
 pts=[(x-w/2,y-h/2,z),(x+w/2,y-h/2,z),(x+w/2,y+h/2,z),(x-w/2,y+h/2,z)]
 if side:pts=[(x,y-h/2,z+w/2),(x,y-h/2,z-w/2),(x,y+h/2,z-w/2),(x,y+h/2,z+w/2)]
 uv=[(0,1),(1,1),(1,0),(0,0)];idx=[0,1,2,0,2,3];mesh(name,sec,[pts[i] for i in idx],[(1,0,0) if side else (0,0,1)]*6,[uv[i] for i in idx],len(g['materials'])-1)
# Architecture, Y up, front +Z. Each floor owns its slab and all details.
box('Plaza','environment',0,-.25,0,19,.35,11,'base');box('Paving','environment',0,-.05,0,18.8,.08,10.8,'peach')
box('Values plinth','foundation',0,.45,0,15,.9,7.5,'base')
for i,text in enumerate(sections[0]['items']):label('Value_'+str(i),'foundation',text,-4.8+i*4.8,.45,3.76,4.55,.65)
for floor,w,d,cx in [(1,14,6.6,0),(2,14,6.5,0),(3,10.3,5.5,-.5),(4,7.5,4.8,.2)]:
 sec='floor'+str(floor);bottom=.95+(floor-1)*2.75;top=bottom+2.75;front=d/2
 box('Slab_'+sec,sec,cx,bottom,0,w,.22,d,'peach');box('Rear_'+sec,sec,cx,bottom+1.4,-d/2+.15,w-.3,2.5,.2)
 for xx in [cx-w/2+.2,cx+w/2-.2]:box('Pillar_'+sec,sec,xx,bottom+1.35,front-.2,.32,2.55,.32)
 for i in range(max(3,int(w/1.2))):
  xx=cx-w/2+.7+i*1.15
  if xx>cx+w/2-.4:break
  box('Window_'+sec,sec,xx,bottom+1.35,front-.55,1.05,2.25,.1,'glass')
 for zz in [-1.4,0,1.4]:box('Side window_'+sec,sec,cx+w/2-.16,bottom+1.35,zz,.08,2.1,1.25,'glass')
 box('Cornice_'+sec,sec,cx,top-.05,0,w+.2,.25,d+.2,'peach')
 label('Floor title_'+sec,sec,sections[floor]['title'],cx,top-.06,front+.12,w-.3,.24,bg='#168f78',fg='#ffffff')
 label('Side title_'+sec,sec,sections[floor]['title'],cx+w/2+.115,top-.06,0,d-.2,.24,bg='#168f78',fg='#ffffff',side=True)
# First floor: 5 dedicated columns, broad entrance on the left.
for i,txt in enumerate(sections[1]['items'][:5]):
 x=-1.6+i*1.75;box('Column_'+str(i+1),'floor1',x,2.23,3.42,.63,2.4,.65);box('Column foot','floor1',x,1.15,3.42,.9,.25,.9)
 label('Column text_'+str(i+1),'floor1',txt,x,2.35,3.751,.58,1.85,bg='#eee2c5')
box('Entry canopy','floor1',-4.4,3.15,3.8,2.6,.22,1.5)
for x in [-5.45,-3.35]:box('Entrance pier','floor1',x,2,4.1,.28,2.1,.28)
label('Employer','floor1',sections[1]['items'][5],7.02,2.15,0,5.7,1.05,side=True)
# Production blocks. Pushkino left; Obolensk right. Shared goal strip.
p=sections[2]['items']
label('Biotech extracts','floor2',p[0]+'\n\n'+p[1],-5.05,5.12,3.29,3.1,2.04)
label('Tablets','floor2',p[2],-1.5,5.85,3.3,3.6,.67)
label('Obolensk initiatives','floor2',p[5]+'\n\n'+p[6],3.65,5.15,3.29,5.75,1.6)
label('Pushkino','floor2',p[3],-3.4,4.05,3.35,6.4,.32,bg='#efe4c9')
label('Obolensk','floor2',p[4],3.4,4.05,3.35,6.4,.32,bg='#efe4c9')
label('Shared production goal','floor2',p[7],0,3.79,3.36,13.5,.32)
label('Planning','floor2',p[8],7.02,5.55,0,5.5,.75,side=True)
# conveyors with small packages, visible below tablets header
box('Conveyor','floor2',-1.4,4.55,2.72,3,.3,.7,'teal')
for i in range(15):box('Conveyor roller','floor2',-2.8+i*.2,4.73,2.72,.09,.06,.64,'metal')
for i in range(4):box('Package','floor2',-2.6+i*.65,4.91,2.73,.3,.3,.3,'peach')
# side tanks (stylized rectangular industrial vessels)
for z in [-1.3,0,1.3]:box('Process vessel','floor2',6.65,4.75,z,.52,1.2,.75,'metal')
# Portfolio: six placards across front; combine the two linked initiatives
texts=[sections[3]['items'][0],sections[3]['items'][1]+'\n\n'+sections[3]['items'][2],*sections[3]['items'][3:]]
for i,text in enumerate(texts):label('Portfolio_'+str(i),'floor3',text,-4.68+i*1.68,7.83,2.8,1.52,2.13)
# financial storey and mission roof
label('Financial indicators','floor4','\n'.join(sections[4]['items']),1.3,10.5,2.46,4.8,2.1)
box('Mission roof','mission',.2,12.06,0,8,.26,5.2,'peach')
label('Mission','mission','МИССИЯ КОМПАНИИ\n'+sections[5]['items'][0],.2,12.12,2.65,7.9,.65,bg='#158c76',fg='#ffffff')
for x in [-2.8,2.7]:box('Sign support','mission',x,12.8,-.4,.09,1.2,.09,'metal')
box('Roof sign backing','mission',.2,13.25,-.36,7.8,1.05,.18,'cream')
label('Brand','mission','gPh  ГЕРОФАРМ',.2,13.25,-.255,7.65,.96,bg='#eee9da',fg='#173f39')
# Landscape: planters, benches, lamp posts
for x in [-5.8,-3,1,3.2]:
 box('Planter','environment',x,.98,4.35,.6,.5,.6,'peach');box('Topiary','environment',x,1.7,4.35,.43,.95,.43,'green')
for z in [-3,-2,-1,0,1,2,3]:box('Shrub','environment',8,.36,z,.75,.6,.7,'green')
for x in [-7.8,7.8]:
 for z in [-4.6,4.6]:
  box('Lamp pole','environment',x,1.5,z,.065,3,.065,'metal');box('Lamp head','environment',x,3,z,.55,.1,.16,'metal')
for x in [-5,4]:
 box('Bench seat','environment',x,.44,4.95,1.3,.12,.35,'teal')
 for dx in [-.48,.48]:box('Bench foot','environment',x+dx,.23,4.95,.12,.4,.3,'green')
g['buffers']=[{'byteLength':len(binary)}]
raw=json.dumps(g,ensure_ascii=False,separators=(',',':')).encode();raw+=b' '*((-len(raw))%4);binary+=b'\0'*((-len(binary))%4)
result=b'glTF'+struct.pack('<II',2,12+8+len(raw)+8+len(binary))+struct.pack('<II',len(raw),0x4e4f534a)+raw+struct.pack('<II',len(binary),0x004e4942)+binary
(OUT/'geropharm-house.glb').write_bytes(result)
print('Created',len(result),'bytes;',len(g['meshes']),'meshes;',len(g['images']),'text textures')
