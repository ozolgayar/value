import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

const $ = id => document.getElementById(id);
const container = $('viewport');
const scene = new THREE.Scene(); scene.background = new THREE.Color('#e4ebe7');
const camera = new THREE.PerspectiveCamera(36,1,.1,120);
const renderer = new THREE.WebGLRenderer({antialias:true});
renderer.setPixelRatio(Math.min(devicePixelRatio,2));
renderer.outputColorSpace=THREE.SRGBColorSpace;
renderer.toneMapping=THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure=1.25;
container.appendChild(renderer.domElement);
const controls=new OrbitControls(camera,renderer.domElement);
controls.target.set(0,6,0); camera.position.set(19,17,30);
controls.enableDamping=true; controls.enablePan=false;
controls.minDistance=12; controls.maxDistance=52;
controls.minPolarAngle=.85; controls.maxPolarAngle=1.48;
controls.minAzimuthAngle=-.18; controls.maxAzimuthAngle=.85;
controls.update(); controls.saveState();
scene.add(new THREE.HemisphereLight('#fff8e7','#6b8a82',2.3));
const key=new THREE.DirectionalLight('#fff0db',3.2); key.position.set(-8,18,15);scene.add(key);
const fill=new THREE.DirectionalLight('#cdebe7',1);fill.position.set(10,8,-10);scene.add(fill);
let model,sections=[],selected=null,done=new Set();const meshes=[],lights=new Map();
try{const saved=JSON.parse(localStorage.getItem('geropharm-progress-v1')||'[]');if(Array.isArray(saved))done=new Set(saved);}catch{}
function save(){try{localStorage.setItem('geropharm-progress-v1',JSON.stringify([...done]));}catch{}}
function renderUI(){
 $('progress').textContent=`Пройдено ${done.size} из 6`;
 for(const b of $('sections').children){b.classList.toggle('active',selected===b.dataset.id);b.classList.toggle('done',done.has(b.dataset.id));b.setAttribute('aria-pressed',String(selected===b.dataset.id));}
 if(selected){$('status').textContent=done.has(selected)?'РАЗДЕЛ ПРОЙДЕН':'ЗНАКОМСТВО С РАЗДЕЛОМ';$('complete').textContent=done.has(selected)?'Снять отметку о прохождении':'Отметить пройденным';}
}
function select(id){const section=sections.find(s=>s.id===id);if(!section)return;selected=id;$('title').textContent=section.title;$('text').replaceChildren(...section.items.map(text=>{const p=document.createElement('p');p.textContent=text;return p;}));$('card').hidden=false;renderUI();}
$('close').onclick=()=>{selected=null;$('card').hidden=true;renderUI();};
$('complete').onclick=()=>{if(!selected)return;if(done.has(selected))done.delete(selected);else done.add(selected);save();renderUI();};
$('reset').onclick=()=>{done.clear();save();renderUI();};
$('resetView').onclick=()=>controls.reset();
const raycaster=new THREE.Raycaster(),pointer=new THREE.Vector2();let down;
renderer.domElement.addEventListener('pointerdown',e=>{down=[e.clientX,e.clientY];});
renderer.domElement.addEventListener('pointerup',e=>{if(!down||Math.hypot(e.clientX-down[0],e.clientY-down[1])>6)return;down=null;const r=renderer.domElement.getBoundingClientRect();pointer.set((e.clientX-r.left)/r.width*2-1,-(e.clientY-r.top)/r.height*2+1);raycaster.setFromCamera(pointer,camera);const hit=raycaster.intersectObjects(meshes,false)[0];if(hit)select(hit.object.userData.sectionId);});
renderer.domElement.addEventListener('pointercancel',()=>down=null);
function resize(){const w=container.clientWidth,h=container.clientHeight;renderer.setSize(w,h);camera.aspect=w/h;camera.fov=w/h<.8?50:36;camera.updateProjectionMatrix();}
new ResizeObserver(resize).observe(container);resize();
async function init(){
 const response=await fetch('/sections.json');if(!response.ok)throw new Error('Не загружен sections.json');sections=await response.json();
 done=new Set([...done].filter(id=>sections.some(s=>s.id===id)));
 for(const s of sections){const b=document.createElement('button');b.textContent=s.title;b.dataset.id=s.id;b.onclick=()=>select(s.id);$('sections').append(b);}
 const gltf=await new GLTFLoader().loadAsync('/geropharm-house.glb');model=gltf.scene;scene.add(model);
 model.traverse(obj=>{if(!obj.isMesh)return;const id=obj.userData.sectionId;if(!sections.some(s=>s.id===id))return;obj.material=obj.material.clone();obj.userData.baseColor=obj.material.color.clone();obj.userData.role=obj.material.userData.role||'';meshes.push(obj);});
 for(let i=0;i<sections.length;i++){const light=new THREE.PointLight('#ffe3ad',0,9,2);light.position.set(0,i===0?1: i===5?12:1+i*2.75,3.8);scene.add(light);lights.set(sections[i].id,light);}
 $('loading').hidden=true;renderUI();
}
init().catch(err=>{$('loading').textContent='Не удалось загрузить модель. Запустите проект через npm run dev. Подробности — в консоли.';console.error(err);});
const clock=new THREE.Clock();
renderer.setAnimationLoop(()=>{const dt=Math.min(clock.getDelta(),.05),t=1-Math.exp(-dt*6);controls.update();
 for(const mesh of meshes){const id=mesh.userData.sectionId,complete=done.has(id),active=selected===id,role=mesh.userData.role;const m=mesh.material;
 const brightness=complete?1:active?.95:.69;
 m.color.lerp(mesh.userData.baseColor.clone().multiplyScalar(role==='text'?Math.max(.88,brightness):brightness),t);
 const target=role==='glass'?(complete?.8:active?.23:.035):role==='text'?0:complete?.055:active?.025:0;
 m.emissive.setRGB(.16,1,.65);m.emissiveIntensity=THREE.MathUtils.lerp(m.emissiveIntensity,target,t);
 }
 for(const [id,light] of lights)light.intensity=THREE.MathUtils.lerp(light.intensity,done.has(id)?20:selected===id?5:0,t);
 renderer.render(scene,camera);
});

// Optional manual boot from a host application. The demo uses the same function.
window.houseApp={selectSection:select,setCompleted(ids){done=new Set(ids.filter(id=>sections.some(s=>s.id===id)));save();renderUI();},getCompleted(){return [...done];}};
